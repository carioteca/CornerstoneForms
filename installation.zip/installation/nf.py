import json
import re

with open('json_files\Indemnification_Agreement.json') as ind:
    data = json.load(ind)

name_decedent = data['the decedent']

res = re.split(" ", name_decedent)

qtd = len(res)
first_name = res[0]
last_name = res[qtd-1]

middle_name = ' '

if qtd == 2:
    middle_name = ' '

if qtd == 3:
    middle_name = res[1]

else:
   ultimo = qtd-1
   for i in range(qtd):
      pos = i
      if i!= 0 and i!=ultimo:
        middle_name += " "+res[pos]


name_final = last_name.strip()+' '+first_name.strip()+' '+middle_name.strip()

