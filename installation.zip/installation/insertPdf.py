from PyPDF2 import PdfFileReader
import json
import glob
import pdfrw
import nf
    
with open('json_files\Order_for_Release_form.json') as order:
    data = json.load(order)

with open('json_files\Indemnification_Agreement.json') as ind:
    data2 = json.load(ind)

ANNOT_KEY = '/Annots'
ANNOT_FIELD_KEY = '/T'
ANNOT_VAL_KEY = '/V'
ANNOT_RECT_KEY = '/Rect'
SUBTYPE_KEY = '/Subtype'
WIDGET_SUBTYPE_KEY = '/Widget'

def insertAuthMini(di, saida):
    data_dict = {
        '0':nf.last_name, 
        '1':nf.first_name,
        '2':nf.middle_name
    }
    template_pdf = pdfrw.PdfReader(di)
    #First Page
    c=0
    annotations = template_pdf.pages[0][ANNOT_KEY] 
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
            if annotation[ANNOT_FIELD_KEY]: 
                key = annotation[ANNOT_FIELD_KEY][1:-1] 
                if key in data_dict.keys():
                    if c == 2 or c==3 or c==4:
                        update = {
                            'V': data_dict[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))
                    c+=1  
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Authorization_For_Minimal_Preparation_complete.pdf",template_pdf)     
    
def insertAuth(di, saida):
    data_dict = {
        'Text2': data['case_number'], 
        'ggggyyykk': nf.name_final,#decedent
    }


    data_dict1 = {
        'Text28': data['case_number'], 
        'Text30': nf.name_final,#decedent
    }

    template_pdf = pdfrw.PdfReader(di)

    #First Page
    annotations = template_pdf.pages[0][ANNOT_KEY] 
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
            if annotation[ANNOT_FIELD_KEY]: 
                key = annotation[ANNOT_FIELD_KEY][1:-1] 
                if key in data_dict.keys(): 
                        update = {
                            'V': data_dict[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))  
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Authorization_for_Cremation_complete.pdf",template_pdf)     

    #Second Pages
    annotations = template_pdf.pages[1][ANNOT_KEY] 
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
            if annotation[ANNOT_FIELD_KEY]: 
                key = annotation[ANNOT_FIELD_KEY][1:-1] 
                if key in data_dict1.keys(): 
                        update = {
                            'V': data_dict1[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))  
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Authorization_for_Cremation_complete.pdf",template_pdf)     
        
def insertRisk(di, saida):
    data_dict = {
        '0': data2['informant'], #Informant
        # '0':data['signature'], #signature
        # '0_val2': data['case_number'], #present1
        # 'Text3': data['case_number'], #date
        # '0_val3': data['case_number'],#present2
        # '1_val2': data['case_number']#present3
    }

    c=0
    template_pdf = pdfrw.PdfReader(di)
    annotations = template_pdf.pages[0][ANNOT_KEY] 
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
            if annotation[ANNOT_FIELD_KEY]: 
                key = annotation[ANNOT_FIELD_KEY][1:-1] 
                if key in data_dict.keys(): 
                    if c ==0:
                        update = {
                            'V': data_dict[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))  
                    c+=1
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Assumption_of_Risk_complete.pdf",template_pdf)     


def insertAuthCol(di, saida):

    data_last = {
        '0': nf.last_name,

    }

    data_first= {
        '1': nf.first_name

    }

    data_midle= {
        '2': nf.middle_name

    }


    template_pdf = pdfrw.PdfReader(di)

    annotations = template_pdf.pages[0][ANNOT_KEY] 

    c= 0
    c1 = 0
    c2 = 0
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
            if annotation[ANNOT_FIELD_KEY]: 
                key = annotation[ANNOT_FIELD_KEY][1:-1]           
                if key in data_last.keys(): 
                    if c == 0:
                        update = {
                            'V': data_last[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))  
                    c+=1
                if key in data_first.keys():      
                    if c1==1:
                        update = {
                            'V': data_first[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update)) 
                    c1+=1     
                if key in data_midle.keys():      
                    if c2==1:
                        update = {
                            'V': data_midle[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update)) 
                    c2+=1
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Authorization_to_Collect_Fingerprint_complete.pdf",template_pdf)     

def insertAuthEmb(di, saida):

    data_dict = {
        'Text1': nf.name_final 
    }


    template_pdf = pdfrw.PdfReader(di)

    #First Page
    annotations = template_pdf.pages[0][ANNOT_KEY] 
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
            if annotation[ANNOT_FIELD_KEY]: 
                key = annotation[ANNOT_FIELD_KEY][1:-1] 
                if key in data_dict.keys():
                        update = {
                            'V': data_dict[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Authorization_To_Embalm_complete.pdf",template_pdf)     

def insertChainOf(di, saida):

    data_dict = {
        'Text1':nf.name_final,
        'Text7': data['case_number']
     }

    template_pdf = pdfrw.PdfReader(di)
    #First Page
    annotations = template_pdf.pages[0][ANNOT_KEY] 
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1] 
                 if key in data_dict.keys():
                        update = {
                            'V': data_dict[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))
                      
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Chain_Of_Custody_complete.pdf",template_pdf)     

def insertCremaCerti(di, saida):
    data_dict = {
        'TextField': data['decedent'],
        'who passed awayon?':data['decedent'],
        'Metal Identification Disc Number': data['case_number']
     }
    template_pdf = pdfrw.PdfReader(di)
    annotations = template_pdf.pages[0][ANNOT_KEY] 
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1] 
                 if key in data_dict.keys(): 
                      update = {
                          'V': data_dict[key],
                      }
                      annotation.update(pdfrw.PdfDict(**update))  
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Cremation_Certificate_complete.pdf",template_pdf)     

def insertCremaCont(di, saida):
    data_dict = {
        'Text5': nf.name_final,
        'Text3': data['case_number'],
        'Text17': data['case_number']
    }
    template_pdf = pdfrw.PdfReader(di)

    annotations = template_pdf.pages[0][ANNOT_KEY] 

    annotations = template_pdf.pages[0][ANNOT_KEY] 
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
            if annotation[ANNOT_FIELD_KEY]: 
                key = annotation[ANNOT_FIELD_KEY][1:-1] 
                if key in data_dict.keys():
                    update = {
                                'V': data_dict[key],
                    }
                    annotation.update(pdfrw.PdfDict(**update))
            template_pdf.Root.AcroForm.update(   
                pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
            )
            pdfrw.PdfWriter().write(saida+"\Cremation_Control_Sheet_complete.pdf",template_pdf)   

def insertCremaIden(di, saida):

    data_dict = {
        'Text1': data['decedent'],
        'Text9': data2['printed name'],
        'Text25':data['witness'],
        'Text32':data['case_number'],
        'Text28': data['decedent']

    }

    template_pdf = pdfrw.PdfReader(di)

    annotations = template_pdf.pages[0][ANNOT_KEY] 
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
            if annotation[ANNOT_FIELD_KEY]: 
                key = annotation[ANNOT_FIELD_KEY][1:-1] 
                if key in data_dict.keys():
                    update = {
                                'V': data_dict[key],
                    }
                    annotation.update(pdfrw.PdfDict(**update))
            template_pdf.Root.AcroForm.update(   
                pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
            )
            pdfrw.PdfWriter().write(saida+"\Cremation_Identification_complete.pdf",template_pdf)   

def insertCremaLabel(di,saida):#check

    data_dict = {
        'TextField': data['decedent'],
        'TextField_2': data['decedent'],
        'TextField_3': data['decedent']
    }


    template_pdf = pdfrw.PdfReader(di)


    annotations = template_pdf.pages[0][ANNOT_KEY] 
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
            if annotation[ANNOT_FIELD_KEY]: 
                key = annotation[ANNOT_FIELD_KEY][1:-1] 
                if key in data_dict.keys():
                    update = {
                                'V': data_dict[key],
                    }
                    annotation.update(pdfrw.PdfDict(**update))
            template_pdf.Root.AcroForm.update(   
                pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
            )
            pdfrw.PdfWriter().write(saida+"\Cremation_Label_complete.pdf",template_pdf)   

def insertIdentAck(di, saida):
    data_dict = {
        '0':nf.last_name,
        '1':nf.first_name,
        '2':nf.middle_name
     }
    template_pdf = pdfrw.PdfReader(di)
    #First Page
    c=0
    annotations = template_pdf.pages[0][ANNOT_KEY] 
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1] 
                 if key in data_dict.keys():
                      if c == 2 or c==3 or c==4:
                        update = {
                            'V': data_dict[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))
                      c+=1  
                      
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Identification_Acknowledgement_complete.pdf",template_pdf)     

def insertLack(di,saida):
    data_dict = {
        'Text4': data['decedent'],
     }

    data_dict1 = {
        '0':data2['informant']
     }
    template_pdf = pdfrw.PdfReader(di)
    annotations = template_pdf.pages[0][ANNOT_KEY] 
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1] 
                 if key in data_dict.keys(): 
                      update = {
                          'V': data_dict[key],
                      }
                      annotation.update(pdfrw.PdfDict(**update))  
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Lack_of_Burial_complete.pdf",template_pdf)     
    data_dict2 = {
        '0':data2['printed name']
    }

    c=0
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1] 
                 if key in data_dict2.keys(): 
                    if c == 0: 
                      update = {
                          'V': data_dict2[key],
                      }
                      annotation.update(pdfrw.PdfDict(**update))  
                    c+=1  
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Lack_of_Burial_complete.pdf",template_pdf)     


    c=0
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1] 
                 if key in data_dict1.keys(): 
                    if c == 0: 
                      update = {
                          'V': data_dict1[key],
                      }
                      annotation.update(pdfrw.PdfDict(**update))  
                    c+=1  
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Lack_of_Burial_complete.pdf",template_pdf)         

def insertObit(di, saida):
    data_dict = {
        'Text2': data['decedent'],
        'Text41': data['decedent']
     }
    template_pdf = pdfrw.PdfReader(di)
    annotations = template_pdf.pages[0][ANNOT_KEY] 
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1] 
                 if key in data_dict.keys(): 
                      update = {
                          'V': data_dict[key],
                      }
                      annotation.update(pdfrw.PdfDict(**update))  
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Obituary_Information_Sheet_complete.pdf",template_pdf)     

def insertPersonal(di,saida):
    template_pdf = pdfrw.PdfReader(di)
    annotations = template_pdf.pages[0][ANNOT_KEY] 
    data_dict = {
    '0': nf.last_name
    }
    c= 0
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1] 
                 if key in data_dict.keys(): 
                     if c == 3:
                        update = {
                            'V': data_dict[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))  
                    #  print(c)
                     c+=1
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Personal_Effects_Inventory_complete.pdf",template_pdf)     
    data_dict1 = {
        '1': nf.first_name
     }
    c= 0
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1] 
                 if key in data_dict1.keys(): 
                     if c == 1:
                        update = {
                            'V': data_dict1[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))  
                     c+=1
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Personal_Effects_Inventory_complete.pdf",template_pdf)    
    data_dict2 = {
        '2': nf.middle_name
     }
    c= 0
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1] 
                 if key in data_dict2.keys(): 
                        update = {
                            'V': data_dict2[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))  
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Personal_Effects_Inventory_complete.pdf",template_pdf)    

def insertReceipt(di, saida):
    data_last = {
        '0': nf.last_name,

     }

    data_first= {
        '1': nf.first_name

     }

    data_midle= {
        '2': nf.middle_name

     }

    data_dict = {
         'Text10': data['case_number'],
         'Text11': data2['informant'],
         'Text8': data2['signature'],
         'Text12': data2['kinship'],
     }

    data_witness = {
         '1': data['witness'],
        #  '0': data['witness_signed']
     }


    template_pdf = pdfrw.PdfReader(di)

    annotations = template_pdf.pages[0][ANNOT_KEY] 

    c= 0
    c1 = 0
    c2 = 0
    c3 = 0
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1] 
                 if key in data_dict.keys():
                     update = {
                            'V': data_dict[key]
                        }
                     annotation.update(pdfrw.PdfDict(**update)) 

                 if key in data_last.keys(): 
                     if c == 2:
                        update = {
                            'V': data_last[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))  
                     c+=1
                 if key in data_first.keys():      
                     if c2==0:
                        update = {
                            'V': data_first[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update)) 
                     c1+=1     
                 if key in data_midle.keys():      
                     if c2==0:
                        update = {
                            'V': data_midle[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update)) 
                     c2+=1
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
         )
        pdfrw.PdfWriter().write(saida+"\Receipt_of_Cremated_Remains_complete.pdf",template_pdf)     


    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1]
                 if key in data_witness.keys():
                     if c3==4:
                        update = {
                                'V': data_witness[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))          
                     c3+=1
        template_pdf.Root.AcroForm.update(   
        pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Receipt_of_Cremated_Remains_complete.pdf",template_pdf)     

def insertRental(di, saida):
    data_last = {
        '0': nf.last_name,

     }

    data_first= {
        '1': nf.first_name

     }

    data_midle= {
        '2': nf.middle_name

     }

    data_dict = {
         'Text6': data2['informant'],#informant
         'Text7': data['witness'],#witness
         'Text8': data2['kinship']#relation
     }

    data_witness = {
         '1': data['witness_signed']
        #  '0': data['witness_signed']
     }

    data_informa = {
         '0': data2['informant']
        #  '0': data['witness_signed']
     }


    template_pdf = pdfrw.PdfReader(di)

    annotations = template_pdf.pages[0][ANNOT_KEY] 

    c= 0
    c1 = 0
    c2 = 0
    c3 = 0
    c4 = 0

    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1]
                 if key in data_witness.keys():
                     if c3==3:
                        update = {
                                'V': data_witness[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))          
                     c3+=1
                 if key in data_informa.keys():
                     if c4==3:
                        update = {
                                'V': data_informa[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))          
                     c4+=1                 
        template_pdf.Root.AcroForm.update(   
        pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
        )
        pdfrw.PdfWriter().write(saida+"\Rental_Casket_Acknowledgement_complete.pdf",template_pdf)     

    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1] 
                 if key in data_dict.keys():
                    update = {
                        'V': data_dict[key],
                    }
                    annotation.update(pdfrw.PdfDict(**update))  
                 if key in data_last.keys(): 
                     if c == 1:
                        update = {
                            'V': data_last[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))  
                     c+=1
                 if key in data_first.keys():      
                     if c2==0:
                        update = {
                            'V': data_first[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update)) 
                     c1+=1     
                 if key in data_midle.keys():      
                     if c2==0:
                        update = {
                            'V': data_midle[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update)) 
                     c2+=1
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
         )
        pdfrw.PdfWriter().write(saida+"\Rental_Casket_Acknowledgement_complete.pdf",template_pdf)     

def insertWitness(di,saida):
    data_last = {
        '0': nf.last_name,

     }

    data_first= {
        '1': nf.first_name

     }

    data_midle= {
        '2': nf.middle_name

     }

    data_dict = {
        'Text9':data2['decedent']
    }



    template_pdf = pdfrw.PdfReader(di)

    annotations = template_pdf.pages[0][ANNOT_KEY] 

    c= 0
    c1 = 0
    c2 = 0
    for annotation in annotations:
        if annotation[SUBTYPE_KEY] == WIDGET_SUBTYPE_KEY:
             if annotation[ANNOT_FIELD_KEY]: 
                 key = annotation[ANNOT_FIELD_KEY][1:-1] 
                 if key in data_dict.keys():
                     update = {
                            'V': data_dict[key]
                        }
                     annotation.update(pdfrw.PdfDict(**update))              
                 if key in data_last.keys(): 
                     if c == 0:
                        update = {
                            'V': data_last[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update))  
                     c+=1
                 if key in data_first.keys():      
                     if c2==0:
                        update = {
                            'V': data_first[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update)) 
                     c1+=1     
                 if key in data_midle.keys():      
                     if c2==0:
                        update = {
                            'V': data_midle[key],
                        }
                        annotation.update(pdfrw.PdfDict(**update)) 
                     c2+=1
        template_pdf.Root.AcroForm.update(   
            pdfrw.PdfDict(NeedAppearances=pdfrw.PdfObject('true'))
         )
        pdfrw.PdfWriter().write(saida+"\Witness_of_Removal_complete.pdf",template_pdf)     

def diretorioArquivo(campo2):
    campo = campo2
    cont = 0
    pos = 0
    contador =  0
    qtd = len(campo)
    for x in range(qtd,0, -1):    
        cont = x
        diretorio = str(campo)
        caminho = diretorio[cont-1]
        if caminho == "/" and contador==0:
            pos = cont-1
            contador += 1
            break
    diretorio = diretorio[0:pos] 
    return diretorio 

def folderFiles(di, saida): 
    risk_as = di+"\Assumption_of_Risk_and_Hold_Harmless.pdf"
    risk = glob.glob(risk_as)
    #
    auth_for = di+"\Authorization_for_Cremation_and_Disposition.pdf"
    auth = glob.glob(auth_for)
    #
    auth_for_m = di+"\Authorization_For_Minimal_Preparation.pdf"
    auth_m = glob.glob(auth_for_m)
    #
    auth_colle =  di+"\Authorization_to_Collect_Fingerprint.pdf"
    auth_co = glob.glob(auth_colle)
    #
    auth_embal =  di+"\AuthorizationTo_Embalm.pdf"
    auth_em = glob.glob(auth_embal)
    #
    chain_of = di+"\Chain_Of_Custody_And_Identification_Confirmation_blank.pdf"
    chain = glob.glob(chain_of)
    #
    cremation_cert = di+"\Cremation_Certificate.pdf"
    cr_cert = glob.glob(cremation_cert)
    #
    cremation_cont = di+"\Cremation_Control_Sheet.pdf"
    cr_cont = glob.glob(cremation_cont)
    #
    cremation_ident = di+"\Cremation_Identification.pdf"
    cr_id = glob.glob(cremation_ident)
    #
    cremation_label = di+"\Cremation_Label.pdf"
    cr_label = glob.glob(cremation_label)
    #
    ident = di+"\Identification_Acknowledgement.pdf"
    ident_ack = glob.glob(ident)
    #
    lack_burial = di+"\Lack_of_Burial_Insurance_form.pdf"
    lack = glob.glob(lack_burial)
    #
    obi_info = di+"\Obituary_Information_Sheet.pdf"
    obi = glob.glob(obi_info)
    #
    pers_effect = di+"\Personal_Effects_Inventory_Sheet.pdf"
    pers = glob.glob(pers_effect)
    #
    receipt_of = di+"\Receipt_of_Cremated_Remains.pdf"
    receipt = glob.glob(receipt_of)    
    #
    rental_of = di+"\Rental_Casket_Acknowledgement.pdf"
    rental = glob.glob(rental_of)    
    #
    witness_of = di+"\Witness_of_Removal_of_Human_Remains.pdf"
    witnessof = glob.glob(witness_of)

    if risk!="[]":
        insertRisk(risk_as, saida)
    if auth!="[]":
         insertAuth(auth_for, saida)
    if auth_m!="[]":
        insertAuthMini(auth_for_m, saida)
    if auth_co!="[]":
        insertAuthCol(auth_colle, saida)
    if auth_em!="[]":
        insertAuthEmb(auth_embal, saida)        
    if chain!="[]":
         insertChainOf(chain_of, saida)            
    if cr_cert!="[]":
        insertCremaCerti(cremation_cert, saida)                    
    if cr_cont!="[]":
        insertCremaCont(cremation_cont, saida)                    
    if cr_id!="[]":
        insertCremaIden(cremation_ident, saida)       
    if cr_label!="[]":
        insertCremaLabel(cremation_label, saida)
    if lack!="[]":
        insertLack(lack_burial, saida)        
    if obi!="[]":
        insertObit(obi_info, saida)   
    if pers!="[]":
        insertPersonal(pers_effect, saida)          
    if ident_ack!="[]":
        insertIdentAck(ident, saida)
    if receipt!="[]":
        insertReceipt(receipt_of, saida)        
    if rental!="[]":
        insertRental(rental_of, saida)       
    if witnessof!="[]":
        insertWitness(witness_of, saida)      
