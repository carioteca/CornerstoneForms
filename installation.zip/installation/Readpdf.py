# -*- coding: utf-8 -*-
# -*- coding: cp1252 -*-

from PyPDF2 import PdfFileReader
import json
import glob
import pdfrw

def readOrder(order):
    file_pdf = order
    pdf_reader = PdfFileReader(open(file_pdf, "rb"))
    dictionary  = pdf_reader.getFormTextFields() # returns a python dictionary[]

    keys = [
    'To',
    'date', 
    'decedent',
    'case_number',
    'witness', 
    'witness_date1',
    'witness_signed', 
    'witness_date2',
    'witness_telephone'
    ]

    values = [
        dictionary['Text1'],
        dictionary['Text2'],
        dictionary['Text3'],
        dictionary['Text4'],  
        dictionary['Text18'],
        dictionary['Text17'],
        dictionary['1'],
        dictionary['Text23'],
        dictionary['Text24']+dictionary['Text25']
    ]

    if values[6] == None:
            values[6] = ' '
        
    dictionary_data = {}
    dictionary_data = dict(zip(keys,values))

    a_file = open("json_files\Order_for_Release_form.json", "w", encoding='utf-8')
    json.dump(dictionary_data, a_file, ensure_ascii=False)
    a_file.close()

def folderOrder(campo1): 
    campo = campo1
    cont = 0
    pos = 0
    contador =  0
    qtd = len(campo)
    for x in range(qtd,0, -1):    
        cont = x
        diretorio = str(campo)
        caminho = diretorio[cont-1]
        if caminho == "/" and contador==0:
            pos = cont-1
            contador += 1
            break
    diretorio = diretorio[0:pos]
    order = diretorio + "\Order_for_Release_form.pdf"
    lista_order = glob.glob(order)
    if lista_order!="[]":
        readOrder(str(lista_order[0]))

def readInd(ind):
    pdf = ind

    keys = [
    'informant',
    'kinship',
    'the decedent',
    'room at',
    'decedent',
    'signature',
    'date',
    'printed name',
    'Witnesses1',
    'Witnesses2'
    ]

    values_array = []

    template_pdf = pdfrw.PdfReader(pdf)
    for page in template_pdf.pages:
        annotations = page['/Annots']
        for annotation in annotations:
            if annotation['/Subtype'] == '/Widget':
                if annotation['/V']:
                    value = annotation['/V'][1:-1]
                    values_array.append(value)

    values_dict = [
        values_array[0],
        values_array[1],
        values_array[3],
        values_array[2],
        values_array[4],
        values_array[9],
        values_array[5],
        values_array[6],
        values_array[7],
        values_array[8]
    ]
    

    dictionary_data = {}
    dictionary_data = dict(zip(keys,values_dict ))

    a_file = open("json_files\Indemnification_Agreement.json", "w",encoding='utf-8')
    json.dump(dictionary_data, a_file, ensure_ascii=False)
    a_file.close()    

def folderInd(campo1): 
    campo = campo1
    cont = 0
    pos = 0
    contador =  0
    qtd = len(campo)
    for x in range(qtd,0, -1):    
        cont = x
        diretorio = str(campo)
        caminho = diretorio[cont-1]
        if caminho == "/" and contador==0:
            pos = cont-1
            contador += 1
            break
    diretorio = diretorio[0:pos]
    order = diretorio + "\Indemnification_Agreement.pdf"
    lista_order = glob.glob(order)
    if lista_order!="[]":
        readInd(str(lista_order[0]))

